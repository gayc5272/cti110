import turtle


for i in range(1):
        turtle.forward(80)
        turtle.left(120)
        turtle.forward(80)
        turtle.left(120)
        turtle.forward(80)
        turtle.left(120)
                    
        turtle.forward(50)
        turtle.left(90)
        turtle.forward(50)
        turtle.left(90)
        turtle.forward(50)
        turtle.left(90)
        turtle.forward(50)
        turtle.left(90)
        turtle.forward(50)
