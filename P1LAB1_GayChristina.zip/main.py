user_name = input()

print("Hello", user_name, end="")
print(" and welcome to CS Online!")